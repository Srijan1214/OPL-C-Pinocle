#include "game.h"

using namespace std;

int main() {

	Game game;

	return EXIT_SUCCESS;
}
