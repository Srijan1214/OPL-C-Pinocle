#pragma once

class Static_Constants {
	public:
		static const char m_suit_char_arr[4]; 
		static const char m_face_char_arr[6];
};
