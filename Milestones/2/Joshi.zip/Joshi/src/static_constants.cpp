#include "static_constants.h"

const char Static_Constants::m_suit_char_arr[4] = {'S', 'C', 'H', 'D'};
const char Static_Constants::m_face_char_arr[6] = {'9', 'X', 'J', 'Q', 'K', 'A'};

