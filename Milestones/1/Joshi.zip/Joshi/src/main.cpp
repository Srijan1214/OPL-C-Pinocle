#include "game.h"

using namespace std;

int main() {
	int a;

	Game game;

	return EXIT_SUCCESS;
}
